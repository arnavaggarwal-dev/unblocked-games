"""
FLAPPY?  -- an experiment in humility
A synthwave Flappy Bird clone with a narrator that hates you.

Controls: SPACE / UP / W / click / tap  -> flap, start, restart

Platform notes:
  - pygbag  : IS_WEB guard sizes/letterboxes the display to the actual
              browser window (pygbag's own template stretches the canvas
              and ignores aspect ratio otherwise); touch works via
              FINGERDOWN; async main is required and used.
  - iOS     : input is touch-first (FINGERDOWN mapped to taps), no ESC
              dependency for anything essential, best score persists to
              a local file (best-effort, silent if the sandbox blocks it).
  - Desktop : keyboard + mouse, ESC quits, native window size.

Performance (pygbag/WASM-friendly): all smoothscale / rotate / Surface
allocation is pre-computed or cached; the hot loop is blits only.
"""

import asyncio
import math
import random
import sys

import pygame

IS_WEB = sys.platform == "emscripten"

pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.init()

# --------------------------------------------------------------------------
#  CONFIG
# --------------------------------------------------------------------------
W, H = 420, 680
FPS = 60
HORIZON_Y = int(H * 0.58)
GROUND_Y = H - 70

GRAVITY = 0.55
FLAP_V = -8.4
MAX_FALL = 12.0

PIPE_W = 74
GAP = 172
PIPE_SPEED = 2.75          # was 2.9, reduced by 0.15
PIPE_SPACING = 218

BEST_FILE = "flappy_best.txt"

# --- palette ---
SKY_TOP      = (16,  6,  38)
SKY_MID      = (54, 12,  66)
SKY_HORIZON  = (168, 34,  96)
SUN_TOP      = (255, 214, 66)
SUN_BOT      = (255,  58, 132)
GRID_MAGENTA = (255,  42, 140)
CYAN         = (0,  238, 255)
PIPE_FILL    = (10,  11,  30)
PIPE_EDGE    = (0,  238, 255)
PIPE_LIP     = (120, 255, 255)
GROUND_FILL  = (8,    5,  24)
WHITE        = (240, 240, 250)
GOLD         = (255, 214, 60)
MINT         = (54, 255, 156)
VIOLET       = (167, 92, 255)
PINK         = (255, 45, 149)
GREY         = (130, 130, 150)

NEON_PALETTE = [PINK, CYAN, VIOLET, GOLD, MINT]

# --------------------------------------------------------------------------
#  TAUNTS & COMMENTARY
# --------------------------------------------------------------------------
DEATH_TAUNTS = [
    "SKILL ISSUE.",
    "THE PIPE WON.",
    "GRAVITY: UNDEFEATED.",
    "WAS THAT ON PURPOSE?",
    "A ROCK COULD DO THIS.",
    "THE BIRD DESERVED BETTER.",
    "TRY USING YOUR EYES.",
    "IMPRESSIVELY BAD.",
    "PHYSICS SAYS NO.",
    "HAVE YOU FLOWN BEFORE?",
    "TUTORIAL: CONSIDER IT.",
    "THAT PIPE HAD KIDS.",
    "BOLD OF YOU TO TRY.",
    "REFUND DENIED.",
    "DID YOU BLINK?",
    "0/10. THE BIRD AGREES.",
    "EMBARRASSING, HONESTLY.",
    "THE SUN SAW THAT.",
    "DELETE THE GAME. TRUST ME.",
    "PATHETIC. ADORABLE, THOUGH.",
    "YOUR THUMBS BETRAYED YOU.",
    "BREAKING: BIRD CAN'T FLY.",
    "YOUR ANCESTORS FELT THAT.",
    "STICK TO CHECKERS.",
    "GG. AND BY GG I MEAN NO.",
]

MENU_TAUNTS = [
    "TAP TO EMBARRASS YOURSELF",
    "PRESS SPACE. I DARE YOU.",
    "THE PIPES ARE WAITING.",
    "STILL HERE? SCARED?",
    "READY TO LOSE?",
    "FLAP TO BEGIN THE SUFFERING",
]

# what actually killed you -- shown under the death banner
DEATH_CAUSES = {
    "top":    "CAUSE OF DEATH: TOP PIPE. AMBITIOUS.",
    "bottom": "CAUSE OF DEATH: BOTTOM PIPE. CLASSIC.",
    "ground": "CAUSE OF DEATH: THE FLOOR. IT ALWAYS WINS.",
}

# live gameplay commentary pools
CLOSE_CALL_REMARKS = [
    "THREADED THE NEEDLE.",
    "MILLIMETERS. LITERALLY.",
    "THE PIPE FELT A BREEZE.",
    "TOO CLOSE. SHOW-OFF.",
    "INSURANCE DECLINED THAT.",
]
GRAZE_REMARKS = [
    "PAINT SWAP WITH THE PIPE.",
    "THAT TOUCHED. I SAW IT.",
    "PHYSICS LOOKED AWAY. LUCKY.",
]
CLEAN_STREAK_REMARKS = [
    "SUSPICIOUSLY SMOOTH.",
    "OKAY, AUTOPILOT. RELAX.",
    "CLEAN. WHO EVEN ARE YOU?",
]
GROUND_SAVE_REMARKS = [
    "THE FLOOR FILES A COMPLAINT.",
    "GRAVITY: 'I ALMOST HAD HIM.'",
    "LAST-SECOND. CHECK YOUR PULSE.",
]
WARN_UP_REMARKS = [
    "STEEP CLIMB AHEAD. GOOD LUCK.",
    "UP. UP. UP. NOW.",
]
WARN_DOWN_REMARKS = [
    "NOSEDIVE REQUIRED. DON'T DIE.",
    "DOWN. FAST. YES, THAT DOWN.",
]

def score_jab(score, is_best):
    if is_best and score > 0:
        return "NEW RECORD. THE BAR WAS ON THE FLOOR."
    if score == 0:
        return "zero. a new low. literally."
    if score <= 2:
        return "%d whole pipes. slow down, legend." % score
    if score <= 5:
        return "okay, mildly less terrible."
    if score <= 10:
        return "fine. that was almost good. almost."
    return "showoff. nobody likes a showoff."

MILESTONES = {
    5:  "wow, five. calm down.",
    10: "double digits. shocking.",
    15: "okay, who ARE you",
    20: "this is getting suspicious",
    25: "are you cheating?",
    30: "the pipes fear you now",
    40: "alright, flex over",
    50: "genuinely, why.",
}

# --------------------------------------------------------------------------
#  FONTS
# --------------------------------------------------------------------------
MONO    = "consolas,menlo,dejavusansmono,couriernew,monospace"
F_TINY  = pygame.font.SysFont(MONO, 13, bold=True)
F_SMALL = pygame.font.SysFont(MONO, 16, bold=True)
F_MED   = pygame.font.SysFont(MONO, 22, bold=True)
F_BANNER= pygame.font.SysFont(MONO, 26, bold=True)
F_SCORE = pygame.font.SysFont(MONO, 40, bold=True)

# --------------------------------------------------------------------------
#  TEXT / NEON HELPERS  (memoized -- see performance note at top)
# --------------------------------------------------------------------------
def pixel_text(text, font, color, scale=1):
    surf = font.render(text, False, color)
    if scale != 1:
        surf = pygame.transform.scale(
            surf, (surf.get_width() * scale, surf.get_height() * scale))
    return surf

def _blur(surf, factor):
    w, h = surf.get_size()
    sw, sh = max(1, w // factor), max(1, h // factor)
    small = pygame.transform.smoothscale(surf, (sw, sh))
    return pygame.transform.smoothscale(small, (w, h))

_NEON_CACHE = {}

def _build_neon(text, font, color, scale, pad, glow_factor, glow_passes, chroma):
    base = pixel_text(text, font, color, scale)
    bw, bh = base.get_size()
    canvas = pygame.Surface((bw + pad * 2, bh + pad * 2), pygame.SRCALPHA)
    tmp = pygame.Surface(canvas.get_size(), pygame.SRCALPHA)
    tmp.blit(base, (pad, pad))
    glow = _blur(tmp, glow_factor)
    for _ in range(glow_passes):
        canvas.blit(glow, (0, 0))
    if chroma:
        red = pixel_text(text, font, (255, 40, 80), scale)
        cyn = pixel_text(text, font, (40, 220, 255), scale)
        canvas.blit(red, (pad - 2, pad))
        canvas.blit(cyn, (pad + 2, pad))
    canvas.blit(base, (pad, pad))
    return canvas

def neon_text(text, font, color, scale=1, pad=18, glow_factor=5, glow_passes=3,
              chroma=False):
    key = (text, id(font), color, scale, pad, glow_factor, glow_passes, chroma)
    surf = _NEON_CACHE.get(key)
    if surf is None:
        surf = _build_neon(text, font, color, scale, pad,
                           glow_factor, glow_passes, chroma)
        _NEON_CACHE[key] = surf
    return surf

def blit_center(dst, surf, cx, cy):
    r = surf.get_rect(center=(int(cx), int(cy)))
    dst.blit(surf, r)

# --------------------------------------------------------------------------
#  BEST-SCORE PERSISTENCE (silent best-effort; sandbox-safe)
# --------------------------------------------------------------------------
def load_best():
    try:
        with open(BEST_FILE) as f:
            return int(f.read().strip() or 0)
    except Exception:
        return 0

def save_best(v):
    try:
        with open(BEST_FILE, "w") as f:
            f.write(str(v))
    except Exception:
        pass

# --------------------------------------------------------------------------
#  STATIC BACKGROUND
# --------------------------------------------------------------------------
def lerp_col(a, b, t):
    return (int(a[0]+(b[0]-a[0])*t),
            int(a[1]+(b[1]-a[1])*t),
            int(a[2]+(b[2]-a[2])*t))

def build_background():
    bg = pygame.Surface((W, H))
    for y in range(HORIZON_Y):
        t = y / max(1, HORIZON_Y - 1)
        if t < 0.6:
            col = lerp_col(SKY_TOP, SKY_MID, t / 0.6)
        else:
            col = lerp_col(SKY_MID, SKY_HORIZON, (t - 0.6) / 0.4)
        pygame.draw.line(bg, col, (0, y), (W, y))
    pygame.draw.rect(bg, (12, 6, 30), (0, HORIZON_Y, W, H - HORIZON_Y))

    sun_r = 96
    sun_cx, sun_cy = W // 2, HORIZON_Y - 6
    sun = pygame.Surface((sun_r * 2, sun_r * 2), pygame.SRCALPHA)
    for y in range(sun_r * 2):
        col = lerp_col(SUN_TOP, SUN_BOT, y / (sun_r * 2 - 1))
        pygame.draw.line(sun, col, (0, y), (sun_r * 2, y))
    mask = pygame.Surface((sun_r * 2, sun_r * 2), pygame.SRCALPHA)
    pygame.draw.circle(mask, (255, 255, 255, 255), (sun_r, sun_r), sun_r)
    sun.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    bar_y, thickness = sun_r + 6, 2
    while bar_y < sun_r * 2:
        sun.fill((0, 0, 0, 0), (0, bar_y, sun_r * 2, thickness))
        bar_y += thickness + 4
        thickness += 1
    glow = _blur(sun, 4)
    bg.blit(glow, (sun_cx - sun_r, sun_cy - sun_r))
    bg.blit(glow, (sun_cx - sun_r, sun_cy - sun_r))
    bg.blit(sun,  (sun_cx - sun_r, sun_cy - sun_r))
    pygame.draw.line(bg, CYAN, (0, HORIZON_Y), (W, HORIZON_Y), 2)
    return bg

BG = build_background()

def build_scanlines():
    s = pygame.Surface((W, H), pygame.SRCALPHA)
    for y in range(0, H, 3):
        pygame.draw.line(s, (0, 0, 0, 40), (0, y), (W, y))
    return s

def build_vignette():
    v = pygame.Surface((W, H), pygame.SRCALPHA)
    cx, cy = W / 2, H / 2
    maxd = math.hypot(cx, cy)
    step = 6
    for y in range(0, H, step):
        for x in range(0, W, step):
            d = math.hypot(x - cx, y - cy) / maxd
            a = int(max(0, (d - 0.55)) * 240)
            if a > 0:
                v.fill((0, 0, 0, a), (x, y, step, step))
    return v

_SCANLINES = build_scanlines()
_VIGNETTE  = build_vignette()
OVERLAY = _SCANLINES.copy()
OVERLAY.blit(_VIGNETTE, (0, 0))

# --------------------------------------------------------------------------
#  BIRD (with rotated/squashed frame cache)
# --------------------------------------------------------------------------
def draw_bird_sprite(wing_up):
    base_w, base_h = 22, 16
    s = pygame.Surface((base_w, base_h), pygame.SRCALPHA)
    OUT  = (18, 16, 30)
    BODY = (255, 220, 40)
    BELLY= (255, 150, 20)
    pygame.draw.ellipse(s, OUT,  (1, 2, 18, 13))
    pygame.draw.ellipse(s, BODY, (2, 3, 16, 11))
    pygame.draw.ellipse(s, BELLY,(3, 8, 11,  6))
    if wing_up:
        pygame.draw.ellipse(s, OUT,           (5, 2, 8, 5))
        pygame.draw.ellipse(s, (255, 200, 30),(6, 3, 6, 3))
    else:
        pygame.draw.ellipse(s, OUT,           (5, 8, 8, 5))
        pygame.draw.ellipse(s, (230, 170, 20),(6, 9, 6, 3))
    pygame.draw.circle(s, WHITE, (15, 6), 3)
    pygame.draw.circle(s, OUT,   (16, 6), 1)
    pygame.draw.line(s, OUT, (12, 3), (17, 4), 2)
    pygame.draw.polygon(s, (255, 120, 0), [(18,6),(22,7),(18,9)])
    pygame.draw.polygon(s, OUT,           [(18,6),(22,7),(18,9)], 1)
    return pygame.transform.scale(s, (base_w * 2, base_h * 2))

BIRD_UP   = draw_bird_sprite(True)
BIRD_DOWN = draw_bird_sprite(False)
BIRD_W, BIRD_H = BIRD_UP.get_size()
BIRD_UP_GLOW   = _blur(BIRD_UP, 4)
BIRD_DOWN_GLOW = _blur(BIRD_DOWN, 4)

_BIRD_CACHE = {}

def _bird_frame(frame_up, sqb, angb):
    key = (frame_up, sqb, angb)
    cached = _BIRD_CACHE.get(key)
    if cached is None:
        base  = BIRD_UP if frame_up else BIRD_DOWN
        glowb = BIRD_UP_GLOW if frame_up else BIRD_DOWN_GLOW
        sq = sqb / 10.0
        if sq > 0.01:
            nw = max(1, int(BIRD_W * (1 - 0.18 * sq)))
            nh = max(1, int(BIRD_H * (1 + 0.28 * sq)))
            img  = pygame.transform.scale(base, (nw, nh))
            glow = pygame.transform.scale(glowb, (nw, nh))
        else:
            img, glow = base, glowb
        if angb:
            img  = pygame.transform.rotate(img, angb)
            glow = pygame.transform.rotate(glow, angb)
        cached = (img, glow)
        _BIRD_CACHE[key] = cached
    return cached

class Bird:
    def __init__(self):
        self.x      = 118
        self.y      = H * 0.42
        self.vy     = 0.0
        self.angle  = 0.0
        self.wing_t = 0.0
        self.squash = 0.0
        self.dead   = False
        self.spin   = 0.0

    def flap(self):
        self.vy     = FLAP_V
        self.squash = 1.0

    def update(self):
        self.vy = min(self.vy + GRAVITY, MAX_FALL)
        self.y += self.vy
        self.wing_t += 0.35
        if self.squash > 0:
            self.squash = max(0.0, self.squash - 0.08)
        if self.dead:
            self.spin  += 9
            self.angle  = self.spin
        else:
            target = max(-28, min(90, self.vy * 6))
            self.angle += (-target - self.angle) * 0.25

    def rect(self):
        r = pygame.Rect(0, 0, BIRD_W - 16, BIRD_H - 12)
        r.center = (int(self.x), int(self.y))
        return r

    def draw(self, surf):
        frame_up = (self.vy < 0 or math.sin(self.wing_t) > 0)
        sqb  = min(10, max(0, int(round(self.squash * 10))))
        angb = int(round((self.angle % 360) / 4.0) * 4) % 360
        img, glow = _bird_frame(frame_up, sqb, angb)
        cx, cy = int(self.x), int(self.y)
        surf.blit(glow, glow.get_rect(center=(cx, cy)))
        surf.blit(img,  img.get_rect(center=(cx, cy)))

# --------------------------------------------------------------------------
#  PIPES
# --------------------------------------------------------------------------
class Pipe:
    def __init__(self, x, rng, prev_gap_c=None):
        self.x      = x
        margin      = 120
        self.gap_c  = rng.randint(margin, GROUND_Y - margin)
        self.passed = False
        self.min_clear = 999.0        # smallest clearance seen while inside
        # flag sharp course changes so the narrator can warn about them
        self.warn = None
        if prev_gap_c is not None:
            delta = self.gap_c - prev_gap_c
            if delta <= -190:
                self.warn = "up"
            elif delta >= 190:
                self.warn = "down"

    @property
    def top(self):
        return pygame.Rect(self.x, 0, PIPE_W, self.gap_c - GAP // 2)

    @property
    def bottom(self):
        y = self.gap_c + GAP // 2
        return pygame.Rect(self.x, y, PIPE_W, GROUND_Y - y)

    def update(self):
        self.x -= PIPE_SPEED

    def offscreen(self):
        return self.x + PIPE_W < 0

    def _draw_tube(self, surf, rect, lip_top):
        if rect.height <= 0:
            return
        pygame.draw.rect(surf, PIPE_FILL, rect)
        pygame.draw.rect(surf, PIPE_EDGE, rect, 3)
        inner = rect.inflate(-10, 0)
        if inner.width > 0:
            pygame.draw.line(surf, (0, 120, 150),
                             (inner.left, rect.top), (inner.left, rect.bottom), 2)
        lip_h = 16
        if lip_top:
            lip = pygame.Rect(rect.left - 5, rect.bottom - lip_h,
                              rect.width + 10, lip_h)
        else:
            lip = pygame.Rect(rect.left - 5, rect.top, rect.width + 10, lip_h)
        pygame.draw.rect(surf, PIPE_FILL, lip)
        pygame.draw.rect(surf, PIPE_LIP,  lip, 3)

    def draw(self, surf):
        self._draw_tube(surf, self.top,    lip_top=True)
        self._draw_tube(surf, self.bottom, lip_top=False)

# --------------------------------------------------------------------------
#  PARTICLES (cached circle sprites)
# --------------------------------------------------------------------------
_CIRCLE_CACHE = {}

def _circle(color, size):
    key = (color, size)
    s = _CIRCLE_CACHE.get(key)
    if s is None:
        s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        pygame.draw.circle(s, (*color, 255), (size, size), size)
        _CIRCLE_CACHE[key] = s
    return s

class Particle:
    def __init__(self, x, y, color, vx, vy, life, size):
        self.x, self.y = x, y
        self.vx, self.vy = vx, vy
        self.life = life
        self.max  = life
        self.color= color
        self.size = size

    def update(self):
        self.x  += self.vx
        self.y  += self.vy
        self.vy += 0.15
        self.life -= 1

    def dead(self):
        return self.life <= 0

    def draw(self, surf):
        a = max(0, int(255 * self.life / self.max))
        s = _circle(self.color, self.size)
        s.set_alpha(a)
        surf.blit(s, (self.x - self.size, self.y - self.size))

# --------------------------------------------------------------------------
#  GAME
# --------------------------------------------------------------------------
MENU, PLAY, DEAD = 0, 1, 2

def _browser_size():
    """Inner size of the browser window (pygbag only)."""
    try:
        import platform as _wp
        return int(_wp.window.innerWidth), int(_wp.window.innerHeight)
    except Exception:
        return W, H

class Game:
    def __init__(self):
        # pygbag stretches the canvas to fill the browser window with no
        # regard for aspect ratio. Antidote: make the display the same size
        # as the window (so CSS stretch is 1:1) and letterbox the 420x680
        # game canvas onto it ourselves.
        if IS_WEB:
            self.win_w, self.win_h = _browser_size()
            self.win_w = max(320, self.win_w)
            self.win_h = max(480, self.win_h)
        else:
            self.win_w, self.win_h = W, H
        self.screen = pygame.display.set_mode((self.win_w, self.win_h))
        self._scaled = None
        self._scaled_size = None
        pygame.display.set_caption("FLAPPY?")
        self.clock      = pygame.time.Clock()
        self.canvas     = pygame.Surface((W, H))
        self._grid_scratch = pygame.Surface((W, H - HORIZON_Y), pygame.SRCALPHA)
        self._dim   = pygame.Surface((W, H)); self._dim.fill((0, 0, 0))
        self._flash = pygame.Surface((W, H))
        self.best       = load_best()
        self.grid_phase = 0.0
        self.tick       = 0
        self.last_death_taunt = None
        self.menu_taunt   = random.choice(MENU_TAUNTS)
        self.menu_taunt_t = 0
        self._init_run(initial=True)
        self.state = MENU

    # ------------------------------------------------------------------ run
    def _init_run(self, initial=False):
        self.rng       = random.Random()
        self.bird      = Bird()
        self.pipes     = [Pipe(W + 60, self.rng)]
        self.pipes.append(Pipe(W + 60 + PIPE_SPACING, self.rng,
                               self.pipes[0].gap_c))
        self.particles = []
        self.score     = 0
        self.shake     = 0.0
        self.flash     = 0.0
        self.flash_col = WHITE
        self.death_banner = None
        self.death_jab    = None
        self.death_cause  = None
        self.death_timer  = 0
        self.is_best_run  = False
        self.milestone_text = None
        self.milestone_t    = 0
        self._banner_cache  = {}
        # commentary
        self.remark       = None
        self.remark_col   = CYAN
        self.remark_t     = 0
        self.remark_cool  = 0
        self.clean_streak = 0
        self.save_pending = 0     # frames since a low-altitude rescue flap
        if not initial:
            self.state = PLAY

    # ------------------------------------------------------------ commentary
    def say(self, text, color=CYAN, frames=95):
        """Live narrator remark, shown above the ground. Cooldown stops spam."""
        if self.remark_cool > 0:
            return
        self.remark      = text
        self.remark_col  = color
        self.remark_t    = frames
        self.remark_cool = 80

    def _on_pipe_passed(self, pipe):
        half = GAP // 2 - (BIRD_H - 12) // 2   # max |offset| before collision
        margin = abs(self.bird.y - pipe.gap_c)
        if pipe.min_clear < 6:
            self.say(random.choice(GRAZE_REMARKS), GOLD)
            self.clean_streak = 0
        elif margin > half - 14:
            self.say(random.choice(CLOSE_CALL_REMARKS), PINK)
            self.clean_streak = 0
        elif margin < 24:
            self.clean_streak += 1
            if self.clean_streak >= 3:
                self.say(random.choice(CLEAN_STREAK_REMARKS), MINT)
                self.clean_streak = 0
        else:
            self.clean_streak = 0

    # ------------------------------------------------------------- viewport
    def _view(self):
        """(x offset, y offset, scale) of the letterboxed game canvas."""
        scale = min(self.win_w / W, self.win_h / H)
        sw, sh = int(W * scale), int(H * scale)
        return (self.win_w - sw) // 2, (self.win_h - sh) // 2, scale

    def _to_canvas(self, pos):
        """Window/screen coords -> game canvas coords."""
        x0, y0, s = self._view()
        return (int((pos[0] - x0) / s), int((pos[1] - y0) / s))

    def _resize(self, w, h):
        self.win_w, self.win_h = max(1, w), max(1, h)
        self.screen = pygame.display.set_mode((self.win_w, self.win_h))

    # ---------------------------------------------------------------- input
    def flap_action(self):
        if self.state == MENU:
            self._init_run()
        elif self.state == PLAY:
            if not self.bird.dead:
                # remember rescue flaps: max-speed dive arrested near ground
                if self.bird.vy >= MAX_FALL - 0.01 and \
                        self.bird.y > GROUND_Y - 85:
                    self.save_pending = 1
                self.bird.flap()
                self._spawn_flap_dust()
        elif self.state == DEAD and self.death_timer > 26:
            self.menu_taunt = random.choice(MENU_TAUNTS)
            self._init_run()

    def _click(self, pos):
        self.flap_action()

    def handle_event(self, event):
        if event.type == pygame.QUIT:
            return False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                return False
            if event.key in (pygame.K_SPACE, pygame.K_UP, pygame.K_w):
                self.flap_action()
        if event.type == pygame.VIDEORESIZE:
            self._resize(event.w, event.h)
            return True
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self._click(self._to_canvas(event.pos))
        # touch (iOS / Android / mobile browser): normalized coords -> pixels
        if event.type == getattr(pygame, "FINGERDOWN", -1):
            self._click(self._to_canvas((event.x * self.win_w,
                                         event.y * self.win_h)))
        return True

    # ----------------------------------------------------------------- kill
    def kill(self, cause):
        if self.bird.dead:
            return
        self.bird.dead = True
        self.shake     = 16
        self.flash     = 200
        self.flash_col = (255, 60, 90)
        self._spawn_death_burst()
        self.is_best_run = self.score > self.best
        if self.is_best_run:
            self.best = self.score
            save_best(self.best)
        choices = [t for t in DEATH_TAUNTS if t != self.last_death_taunt]
        taunt   = random.choice(choices)
        self.last_death_taunt = taunt
        col = random.choice(NEON_PALETTE)
        self.death_banner = neon_text(taunt, F_BANNER, col, scale=2, pad=26,
                                      glow_factor=6, glow_passes=4, chroma=True)
        self.death_jab   = score_jab(self.score, self.is_best_run)
        self.death_cause = DEATH_CAUSES.get(cause)
        self.state       = DEAD
        self.death_timer = 0

    def _spawn_flap_dust(self):
        for _ in range(6):
            self.particles.append(Particle(
                self.bird.x - 10, self.bird.y + 6,
                random.choice(NEON_PALETTE),
                random.uniform(-2.5, -0.5), random.uniform(-1, 1),
                random.randint(14, 24), random.randint(2, 4)))

    def _spawn_death_burst(self):
        for _ in range(40):
            ang = random.uniform(0, math.tau)
            spd = random.uniform(1.5, 6)
            self.particles.append(Particle(
                self.bird.x, self.bird.y,
                random.choice(NEON_PALETTE),
                math.cos(ang) * spd, math.sin(ang) * spd - 2,
                random.randint(20, 45), random.randint(2, 5)))

    # --------------------------------------------------------------- update
    def update(self):
        self.tick += 1
        self.grid_phase = (self.grid_phase + 0.05) % 16

        for p in self.particles:
            p.update()
        self.particles = [p for p in self.particles if not p.dead()]

        if self.flash > 0:
            self.flash = max(0, self.flash - 12)
        if self.shake > 0.4:
            self.shake *= 0.86
        else:
            self.shake = 0
        if self.remark_t > 0:
            self.remark_t -= 1
        if self.remark_cool > 0:
            self.remark_cool -= 1

        st = self.state
        if st == MENU:
            self.bird.y = H * 0.42 + math.sin(self.tick * 0.06) * 10
            self.menu_taunt_t += 1
            if self.menu_taunt_t > 150:
                self.menu_taunt_t = 0
                self.menu_taunt = random.choice(MENU_TAUNTS)

        elif st == PLAY:
            self.bird.update()
            for pipe in self.pipes:
                pipe.update()
                # pre-warn on sharp course changes as the pipe rolls in
                if pipe.warn and pipe.x < W - 40:
                    pool = WARN_UP_REMARKS if pipe.warn == "up" \
                        else WARN_DOWN_REMARKS
                    self.say(random.choice(pool), VIOLET)
                    pipe.warn = None
            if self.pipes[-1].x < W - PIPE_SPACING:
                self.pipes.append(Pipe(self.pipes[-1].x + PIPE_SPACING,
                                       self.rng, self.pipes[-1].gap_c))
            self.pipes = [p for p in self.pipes if not p.offscreen()]

            br = self.bird.rect()
            for pipe in self.pipes:
                # track how tightly the bird is threading this pipe
                if pipe.x - 26 < self.bird.x < pipe.x + PIPE_W + 10:
                    clear = min(br.top - pipe.top.bottom,
                                pipe.bottom.top - br.bottom)
                    if clear < pipe.min_clear:
                        pipe.min_clear = clear
                if not pipe.passed and pipe.x + PIPE_W < self.bird.x:
                    pipe.passed = True
                    self.score += 1
                    self._on_pipe_passed(pipe)
                    if self.score in MILESTONES:
                        self.milestone_text = MILESTONES[self.score]
                        self.milestone_t = 90
            if self.milestone_t > 0:
                self.milestone_t -= 1

            # a rescue flap only counts once you've actually survived it
            if self.save_pending:
                self.save_pending += 1
                if self.save_pending > 24 and not self.bird.dead:
                    self.say(random.choice(GROUND_SAVE_REMARKS), MINT)
                    self.save_pending = 0

            if br.bottom >= GROUND_Y:
                self.bird.y = GROUND_Y - br.height / 2
                self.kill("ground")
            elif br.top <= 0:
                self.bird.y  = br.height / 2
                self.bird.vy = 1
            else:
                hit = None
                for pipe in self.pipes:
                    if br.colliderect(pipe.top):
                        hit = "top"
                        break
                    if br.colliderect(pipe.bottom):
                        hit = "bottom"
                        break
                if hit:
                    self.kill(hit)

        elif st == DEAD:
            self.death_timer += 1
            if self.bird.y < GROUND_Y - BIRD_H / 2:
                self.bird.update()
                if self.bird.y >= GROUND_Y - BIRD_H / 2:
                    self.bird.y  = GROUND_Y - BIRD_H / 2
                    self.bird.vy = -abs(self.bird.vy) * 0.4
                    if abs(self.bird.vy) > 1:
                        self.shake = max(self.shake, 6)
            else:
                self.bird.update()

    # ----------------------------------------------------------------- draw
    def _draw_grid(self, surf):
        g = self._grid_scratch
        g.fill((0, 0, 0, 0))
        gh = H - HORIZON_Y
        vanish_x = W / 2
        for i in range(-9, 10):
            x_bottom = W / 2 + i * 74
            pygame.draw.line(g, (*GRID_MAGENTA, 90),
                             (vanish_x, 0), (x_bottom, gh), 1)
        N = 16
        phase = self.grid_phase
        for k in range(N):
            t = ((k + phase) % N) / N
            y = gh * (t * t)
            a = int(30 + 110 * t)
            pygame.draw.line(g, (*GRID_MAGENTA, a), (0, y), (W, y), 1)
        surf.blit(g, (0, HORIZON_Y))

    def draw(self):
        c = self.canvas
        c.blit(BG, (0, 0))
        self._draw_grid(c)

        in_world = self.state in (PLAY, DEAD)
        if in_world:
            for pipe in self.pipes:
                pipe.draw(c)

        pygame.draw.rect(c, GROUND_FILL, (0, GROUND_Y, W, H - GROUND_Y))
        pygame.draw.line(c, CYAN,          (0, GROUND_Y),     (W, GROUND_Y),     3)
        pygame.draw.line(c, (0, 90, 110),  (0, GROUND_Y + 4), (W, GROUND_Y + 4), 1)

        for p in self.particles:
            p.draw(c)

        self.bird.draw(c)

        st = self.state
        if st == MENU:
            self._draw_menu(c)
        elif st == PLAY:
            self._draw_score(c)
            self._draw_hud_extras(c)
        elif st == DEAD:
            self._draw_dead(c)

        # composite flash + CRT overlay at native res, then present
        if self.flash > 0:
            self._flash.fill(self.flash_col)
            self._flash.set_alpha(int(self.flash))
            c.blit(self._flash, (0, 0))
        c.blit(OVERLAY, (0, 0))

        ox = oy = 0
        if self.shake > 0.4:
            ox = random.randint(-int(self.shake), int(self.shake))
            oy = random.randint(-int(self.shake), int(self.shake))

        if (self.win_w, self.win_h) == (W, H):
            self.screen.fill((0, 0, 0))
            self.screen.blit(c, (ox, oy))
        else:
            # letterbox: aspect-correct scale, centered, black bars
            x0, y0, scale = self._view()
            sw, sh = int(W * scale), int(H * scale)
            if self._scaled_size != (sw, sh):
                self._scaled_size = (sw, sh)
                self._scaled = pygame.Surface((sw, sh))
            pygame.transform.scale(c, (sw, sh), self._scaled)
            self.screen.fill((0, 0, 0))
            self.screen.blit(self._scaled,
                             (x0 + int(ox * scale), y0 + int(oy * scale)))
        pygame.display.flip()

    def _draw_hud_extras(self, c):
        if self.milestone_t > 0:
            col  = random.choice(NEON_PALETTE) if self.tick % 6 == 0 \
                else NEON_PALETTE[1]
            surf = neon_text(self.milestone_text, F_SMALL, col, pad=12)
            surf.set_alpha(min(255, self.milestone_t * 6))
            blit_center(c, surf, W / 2, 120)
        if self.remark_t > 0:
            surf = neon_text(self.remark, F_SMALL, self.remark_col, pad=12)
            surf.set_alpha(min(255, self.remark_t * 8))
            blit_center(c, surf, W / 2, GROUND_Y - 42)

    def _draw_score(self, c):
        surf = neon_text(str(self.score), F_SCORE, WHITE, pad=16,
                         glow_factor=5, glow_passes=3)
        blit_center(c, surf, W / 2, 70)

    def _draw_menu(self, c):
        title = neon_text("FLAPPY?", F_SCORE, PINK, scale=2, pad=30,
                          glow_factor=6, glow_passes=4)
        blit_center(c, title, W / 2, 150)
        sub = neon_text("an experiment in humility", F_TINY, CYAN, pad=10)
        blit_center(c, sub, W / 2, 205)
        taunt = neon_text(self.menu_taunt, F_SMALL, GOLD, pad=12)
        blit_center(c, taunt, W / 2, 400)
        if (self.tick // 25) % 2 == 0:
            prompt = neon_text("SPACE / TAP", F_MED, MINT, pad=12)
            blit_center(c, prompt, W / 2, 470)
        best = pixel_text("BEST %d" % self.best, F_SMALL, VIOLET)
        c.blit(best, (14, 12))

    def _draw_dead(self, c):
        self._dim.set_alpha(min(150, self.death_timer * 8))
        c.blit(self._dim, (0, 0))

        t   = min(1.0, self.death_timer / 12.0)
        pop = 1.35 - 0.35 * t
        bw, bh = self.death_banner.get_size()
        max_w  = W - 20
        fit    = min(1.0, max_w / bw)
        scale  = min(pop, fit) if fit < 1.0 else pop
        if bw * scale > max_w:
            scale = fit
        skey = round(scale, 2)
        img  = self._banner_cache.get(skey)
        if img is None:
            img = pygame.transform.smoothscale(
                self.death_banner,
                (max(1, int(bw * scale)), max(1, int(bh * scale))))
            self._banner_cache[skey] = img
        blit_center(c, img, W / 2, 200)

        if self.death_timer > 6 and self.death_cause:
            cz = pixel_text(self.death_cause, F_TINY, GREY)
            cz.set_alpha(min(255, (self.death_timer - 6) * 14))
            blit_center(c, cz, W / 2, 245)

        if self.death_timer > 8:
            jcol = GOLD if self.is_best_run else (200, 200, 220)
            jab  = neon_text(self.death_jab, F_SMALL, jcol, pad=12)
            jab.set_alpha(min(255, (self.death_timer - 8) * 14))
            blit_center(c, jab, W / 2, 280)

        if self.death_timer > 16:
            sc = neon_text("SCORE %d" % self.score, F_MED, CYAN, pad=10)
            sc.set_alpha(min(255, (self.death_timer - 16) * 16))
            blit_center(c, sc, W / 2, 345)
            bst = pixel_text("BEST %d" % self.best, F_SMALL, VIOLET)
            bst_r = bst.get_rect(center=(W // 2, 378))
            bst.set_alpha(min(255, (self.death_timer - 16) * 16))
            c.blit(bst, bst_r)

        if self.death_timer > 28 and (self.tick // 25) % 2 == 0:
            again = neon_text("SPACE TO SUFFER AGAIN", F_SMALL, MINT, pad=12)
            blit_center(c, again, W / 2, 440)

# --------------------------------------------------------------------------
#  ASYNC MAIN  (required by pygbag; also fine on desktop/iOS)
# --------------------------------------------------------------------------
async def main():
    game = Game()
    running = True
    while running:
        for event in pygame.event.get():
            if not game.handle_event(event):
                running = False
        game.update()
        game.draw()
        game.clock.tick(FPS)
        await asyncio.sleep(0)
    pygame.quit()

asyncio.run(main())